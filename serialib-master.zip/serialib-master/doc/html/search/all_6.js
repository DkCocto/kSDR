var searchData=
[
  ['opendevice_14',['openDevice',['../classserialib.html#afcef685b74a3db58dc2d1898bb34aaca',1,'serialib']]]
];
