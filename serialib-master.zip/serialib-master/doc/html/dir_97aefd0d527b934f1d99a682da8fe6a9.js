var dir_97aefd0d527b934f1d99a682da8fe6a9 =
[
    [ "serialib.cpp", "serialib_8cpp.html", null ],
    [ "serialib.h", "serialib_8h.html", "serialib_8h" ]
];